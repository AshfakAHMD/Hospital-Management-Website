-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2024 at 09:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `appointment_date` date DEFAULT NULL,
  `appointment_time` time DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `patient_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `patient_id`, `doctor_id`, `appointment_date`, `appointment_time`, `status`, `patient_name`) VALUES
(5, NULL, 2, '2024-11-12', NULL, NULL, 'ashfak'),
(6, NULL, 1, '2024-11-16', NULL, NULL, 'ashfak'),
(7, NULL, 7, '2024-11-15', NULL, NULL, 'Ashfak'),
(8, NULL, 1, '2024-11-14', NULL, NULL, 'ashfak'),
(9, NULL, 1, '2024-11-05', NULL, NULL, 'Ashfak'),
(10, NULL, 1, '2024-11-07', NULL, NULL, 'ashfak'),
(11, NULL, 1, '2024-11-08', NULL, NULL, 'ads'),
(12, NULL, 2, '2024-11-04', NULL, NULL, 'ashfak'),
(13, NULL, 2, '2024-11-14', NULL, NULL, 'Ashfak'),
(14, NULL, 1, '2024-11-23', NULL, NULL, 'ashfak'),
(15, NULL, 1, '2024-11-08', NULL, NULL, 'ashfak'),
(16, NULL, 2, '2024-11-05', NULL, NULL, 'Hana'),
(17, NULL, 2, '2024-11-05', NULL, NULL, 'Hana'),
(18, NULL, 1, '2024-11-20', NULL, NULL, 'Hana Jawfer'),
(19, NULL, 2, '2024-11-14', NULL, NULL, 'Safeek'),
(20, NULL, 3, '2024-11-13', NULL, NULL, 'Ashfak'),
(21, NULL, 3, '2024-11-16', NULL, NULL, 'asfdjagvda'),
(22, NULL, 1, '2024-11-08', NULL, NULL, 'Ahamed'),
(23, NULL, 1, '2024-11-08', NULL, NULL, 'Ahamed'),
(24, NULL, 1, '2024-11-08', NULL, NULL, 'Ahamed'),
(25, NULL, 1, '2024-11-08', NULL, NULL, 'Ahamed'),
(26, NULL, 1, '2024-11-08', NULL, NULL, 'Ahamed'),
(27, NULL, 1, '2024-11-08', NULL, NULL, 'Ahamed'),
(28, NULL, 1, '2024-11-08', NULL, NULL, 'Ahamed');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Cardiologist'),
(2, 'Heart Specialist'),
(3, 'Physiotherapist'),
(4, 'Ophthalmology'),
(5, 'Specialized Mental Health Practitioners'),
(6, 'Physiotherapist');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `specialty` varchar(50) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `profile` text DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `name`, `specialty`, `phone`, `email`, `profile`, `image_path`, `category_id`) VALUES
(1, 'Dr. John Doe', 'Cardiologist', NULL, NULL, NULL, 'images/doctor1.jpg', NULL),
(2, 'Dr. Sarah Smith', 'Neurologist', NULL, NULL, NULL, 'images/doctor2.jpg', NULL),
(3, 'Dr. Michael Brown', 'Orthopedic Surgeon', NULL, NULL, NULL, 'images/doctor3.jpg', NULL),
(4, 'Dr. Emily Davis', 'Cardiologist', NULL, NULL, NULL, 'images/doctor4.jpg', NULL),
(5, 'Dr. Adam White', 'Neurologist', NULL, NULL, NULL, 'images/doctor5.jpg', NULL),
(6, 'Dr. Jane Taylor', 'Orthopedic Surgeon', NULL, NULL, NULL, 'images/doctor6.jpg', NULL),
(7, 'Dr. Robert King', 'Cardiologist', NULL, NULL, NULL, 'images/doctor7.jpg', NULL),
(8, 'Dr. Anna Brooks', 'Neurologist', NULL, NULL, NULL, 'images/doctor8.jpg', NULL),
(9, 'Dr. David Green', 'Orthopedic Surgeon', NULL, NULL, NULL, 'images/doctor9.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctor_det`
--

CREATE TABLE `doctor_det` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `available_time` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_det`
--

INSERT INTO `doctor_det` (`id`, `name`, `category_id`, `available_time`, `image_path`) VALUES
(1, 'Dr. John Doe', 1, '10:00 AM - 11:00 AM', 'images/doctorup1.jpg'),
(2, 'Dr. Jane Smith', 2, '11:00 AM - 1:00 PM', 'images/doctor2.jpg'),
(3, 'Dr. Olivia Carter', 3, '9:00 AM - 12:00 PM', 'images/doctor3.jpg'),
(4, 'Dr. Emily Davis', 1, '1:00 AM - 3:00 PM', 'images/doctor4.jpg'),
(5, 'Dr. Sarah Smith', 2, '2:00 PM - 6:00 PM', 'images/doctor5.jpg'),
(6, 'Dr. Nuha Jawfer', 3, '2:00 PM - 4:00 PM', 'images/doctor6.jpg'),
(7, 'Dr. Fathima Hana', 1, '7:00 AM - 10:00 PM', 'images/doctor7.jpg'),
(8, 'Dr. Vishvani Parindhi', 2, '6:00 PM - 8:00 PM', 'images/doctor8.jpg'),
(9, 'Dr. Michael Brown', 3, '8:00 PM - 11:00 PM', 'images/doctor9.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `expiry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`id`, `name`, `type`, `price`, `quantity`, `expiry_date`) VALUES
(3, 'Amoxicillin', 'Capsule', 3.50, 150, '2024-08-15'),
(4, 'Cough Syrup', 'Syrup', 4.75, 80, '2025-03-20'),
(5, 'Vitamin C', 'Tablet', 0.99, 300, '2027-01-01'),
(6, 'Antacid', 'Tablet', 1.20, 171, '2026-11-11'),
(7, 'Multivitamin', 'Tablet', 2.50, 250, '2025-05-25'),
(8, 'Children\'s Pain Relief', 'Syrup', 5.00, 60, '2024-12-31'),
(9, 'Allergy Relief', 'Tablet', 1.75, 120, '2026-09-30'),
(10, 'Cough Suppressant', 'Syrup', 6.50, 90, '2024-07-01'),
(11, 'Insulin', 'Injection', 15.00, 45, '2025-10-10'),
(12, 'Antibiotic Ointment', 'Cream', 7.25, 38, '2025-08-20'),
(13, 'Pain Relief Gel', 'Gel', 8.99, 30, '2026-04-15'),
(14, 'Oral Rehydration Salts', 'Powder', 1.75, 100, '2027-02-28'),
(15, 'Asthma Inhaler', 'Inhaler', 25.00, 15, '2025-06-10'),
(16, 'Eye Drops', 'Liquid', 3.99, 50, '2024-11-30'),
(17, 'Nasal Spray', 'Spray', 4.99, 40, '2025-09-15'),
(18, 'Fever Reducer', 'Tablet', 1.00, 149, '2026-08-22'),
(19, 'Digestive Enzyme', 'Tablet', 2.99, 100, '2027-03-03'),
(20, 'Antifungal Cream', 'Cream', 5.50, 25, '2026-01-12'),
(21, 'alcohol', 'tablet', 5.00, 4, '0000-00-00'),
(22, 'Neurone', 'Syrup', 56.00, 100, '0000-00-00'),
(23, 'inheler', 'syrup', 6.00, 150, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `medicines_det`
--

CREATE TABLE `medicines_det` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicines_det`
--

INSERT INTO `medicines_det` (`id`, `name`, `description`, `price`, `stock`) VALUES
(1, 'Paracetamol', 'Pain reliever and fever reducer.', 1.50, 100),
(2, 'Ibuprofen', 'Anti-inflammatory drug for pain and fever.', 2.00, 50),
(3, 'Amoxicillin', 'Antibiotic for bacterial infections.', 3.25, 30),
(4, 'Cough Syrup', 'Relieves cough and throat irritation.', 4.50, 20),
(5, 'Antacid Tablets', 'Neutralizes stomach acid.', 1.75, 80),
(6, 'Vitamin C Tablets', 'Boosts immune system.', 2.50, 60),
(7, 'Aspirin', 'Pain reliever and blood thinner.', 2.20, 40),
(8, 'Insulin', 'Used for diabetes management.', 25.00, 15),
(9, 'Multivitamins', 'Daily dietary supplement.', 5.00, 70),
(10, 'Bandages', 'For wound care and protection.', 0.50, 200);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `medicine_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `medicine_id`, `quantity`, `total_amount`, `payment_method`, `order_date`) VALUES
(1, 21, 5, 25.00, 'credit_card', '2024-11-19 04:42:36'),
(2, 6, 4, 4.80, 'credit_card', '2024-11-19 04:43:06'),
(3, 21, 5, 25.00, 'paypal', '2024-11-19 06:06:09'),
(4, 21, 5, 25.00, 'paypal', '2024-11-19 06:07:37'),
(5, 21, 5, 25.00, 'paypal', '2024-11-19 06:07:41'),
(6, 21, 5, 25.00, 'paypal', '2024-11-19 06:08:32'),
(7, 21, 5, 25.00, 'paypal', '2024-11-19 06:08:34'),
(8, 21, 5, 25.00, 'paypal', '2024-11-19 06:08:38'),
(9, 21, 4, 20.00, 'paypal', '2024-11-19 06:08:48'),
(10, 21, 4, 20.00, 'paypal', '2024-11-19 06:11:30'),
(11, 11, 5, 75.00, 'credit_card', '2024-11-19 06:11:55'),
(12, 21, 4, 20.00, 'paypal', '2024-11-19 06:12:13'),
(13, 12, 2, 14.50, 'paypal', '2024-11-19 09:56:05'),
(14, 15, 5, 125.00, 'credit_card', '2024-11-19 17:30:49'),
(15, 21, 5, 25.00, 'credit_card', '2024-11-22 08:33:12'),
(16, 6, 5, 6.00, 'credit_card', '2024-11-25 07:56:11');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `dob` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patient_det`
--

CREATE TABLE `patient_det` (
  `id` int(11) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `patient_id_number` varchar(20) NOT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `reference_name` varchar(255) DEFAULT NULL,
  `reference_contact` varchar(15) DEFAULT NULL,
  `reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_det`
--

INSERT INTO `patient_det` (`id`, `patient_name`, `patient_id_number`, `contact_number`, `reference_name`, `reference_contact`, `reason`) VALUES
(1, 'ashfak', '200128800060', '0717785852', 'ashfak', '0717785852', 'vasjhdvaNHVSJAGSJAGMABCMNA'),
(3, 'asvdhgavdh', '200228800060', '07177858654', 'svbjhv', '0725485986', 'jhsjhvgjhsv'),
(4, 'Hana', '200428800060', '0717785853', 'jawfer', '0726548789', 'habsdjavjdcvaj'),
(5, 'Hana', '200128800070', '0717798956', 'Fathima', '0789565326', 'Admitting for fever'),
(6, 'Ashfak', '20012880060', '0717785852', 'Ahamed', '0725485852', 'fever'),
(7, 'Test', '2002366988850', '0725485852', 'Test1', '0725482852', 'Fever');

-- --------------------------------------------------------

--
-- Table structure for table `prescriptions`
--

CREATE TABLE `prescriptions` (
  `id` int(11) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `doctor_name` varchar(255) NOT NULL,
  `medicine_name` varchar(255) NOT NULL,
  `dosage` varchar(255) NOT NULL,
  `instructions` text DEFAULT NULL,
  `submitted_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prescriptions`
--

INSERT INTO `prescriptions` (`id`, `patient_name`, `doctor_name`, `medicine_name`, `dosage`, `instructions`, `submitted_date`) VALUES
(1, 'Ashfak', 'Arulkumaran', 'ha11', '25', 'Night1', '2024-11-17 14:52:23'),
(2, 'as', 'sa', 'sa', '2', 'fh', '2024-11-17 15:00:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','patient') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', 'admin'),
(2, 'doctor1', 'b3666d14ca079417ba6c2a99f079b2ac', ''),
(3, 'patient1', 'c63f24079f1d5e4cae3fdc1a29116a7b', 'patient'),
(4, 'admin', '$2y$10$zMROVp8J8vG4lBZcsWgvl.v72AX4myFTCqUH6f/GMDyEhihb42I3y', ''),
(5, 'admin', '$2y$10$CvIY3j0y/ib5L5536U6GluPYJJaNNz/aZQzV.Aj9f8vCzUQv8zbl.', 'admin'),
(6, 'admin', '$2y$10$jq/Po2HzrNz92VVp8.byE.h4YIu8AantkU4WyAMtlcPVsZxWJEQOa', 'admin'),
(7, 'ashfak', '$2y$10$Q8Jr9E.u6o4Tqy7MGpRAUunGQ2aB1ktTjPp2oxzYFMJ14Y0d30XQ6', 'admin'),
(8, 'Ashfak', '$2y$10$Ohak6WN6XyBG44U3dRaAr.DQFdKCsj5i7a.cLZcyJ6DbrKqx7YYvO', ''),
(9, 'Hana', '$2y$10$0sJ..kI0q9Cp5D6f0TcP/.HhX.De9XQ0doWwinK9ne5gKLTr/J7/2', ''),
(10, 'muba', '$2y$10$0gN5y08NCkktG6joqVlydOKlbpdDB9cD4d6jrOiMcpmgBqVOr6.RS', 'admin'),
(11, 'sajjadh', '$2y$10$ZfP5uOzCrHbHI7scOjtwA.2tFZp.jv4gO/FUfiVGsNJTQoz0J3Nae', 'patient'),
(12, 'admin1', '$2y$10$IlEXO0p.ghJ2u/hkNTXZxeSuUZQTLkZoE1DK8D1wsfrl9Yha9heXK', 'admin'),
(13, 'ashfak', '$2y$10$L4KPWBqL8IQajKrlf2x0be0lmc91ebUMacU.BVrnNvg/NdPj5FDde', ''),
(14, 'ashif', '$2y$10$oyXDSvTdRvt4sKhaAb7ai.MoGL5GPimwSP2/E72IpNANB6clSvBoa', ''),
(15, 'safeek', '$2y$10$rot013DPiVYrOqAAKj/bTub7/3NOZXX9ayWYY1EuGUBYyyP7aYiKG', 'patient'),
(16, 'sathees', '$2y$10$PAK1VvkVV6S68VjBsqT8DO5GskDjdMbYSxxTIcuj7xXOrpT.JsT72', 'admin'),
(17, 'Kri', '$2y$10$BEgxkUhn1gEXfCKhghJdr.zVA9MssR7EKd8y5So3.H28QBzyv3HIC', 'admin'),
(18, 'ashfak', '$2y$10$6IGWEHi.72hVEmMacQ0HwO/LQFZcWZYLztyxNqw/7rMj4b8XCOv8u', 'admin'),
(19, 'abdullah', '$2y$10$LFh28yFnwry197B8/eWHvuFDBBXUyBUi6ReNKxYlnzBnVGzdo0Z1e', 'admin'),
(20, 'safeek', '$2y$10$eD0vw0eO9QXMEkkVwBHZvOt9JlezYlctVT4VDpNkwfTDD3wWW5uZ2', 'patient');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_det`
--
ALTER TABLE `doctor_det`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicines_det`
--
ALTER TABLE `medicines_det`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `medicine_id` (`medicine_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_det`
--
ALTER TABLE `patient_det`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `patient_id_number` (`patient_id_number`);

--
-- Indexes for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `medicines_det`
--
ALTER TABLE `medicines_det`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patient_det`
--
ALTER TABLE `patient_det`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `prescriptions`
--
ALTER TABLE `prescriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`);

--
-- Constraints for table `doctor_det`
--
ALTER TABLE `doctor_det`
  ADD CONSTRAINT `doctor_det_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`medicine_id`) REFERENCES `medicines` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
