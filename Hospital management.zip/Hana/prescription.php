<?php
include 'config.php';

// Initialize a variable to hold submitted prescription details
$submitted_prescription = null;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $patient_name = $_POST['patient_name'];
    $doctor_name = $_POST['doctor_name'];
    $medicine_name = $_POST['medicine_name'];
    $dosage = $_POST['dosage'];
    $instructions = $_POST['instructions'];

    $sql = "INSERT INTO prescriptions (patient_name, doctor_name, medicine_name, dosage, instructions) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $patient_name, $doctor_name, $medicine_name, $dosage, $instructions);

    if ($stmt->execute()) {
        // Save submitted data to display later
        $submitted_prescription = [
            'patient_name' => $patient_name,
            'doctor_name' => $doctor_name,
            'medicine_name' => $medicine_name,
            'dosage' => $dosage,
            'instructions' => $instructions,
        ];
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Prescription</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Submit Prescription</h1>
    <form method="POST">
        <input type="text" name="patient_name" placeholder="Patient Name" required>
        <input type="text" name="doctor_name" placeholder="Doctor Name" required>
        <input type="text" name="medicine_name" placeholder="Medicine Name" required>
        <input type="text" name="dosage" placeholder="Dosage (e.g., 1 tablet twice a day)" required>
        <textarea name="instructions" placeholder="Additional Instructions" required></textarea>
        <button type="submit">Submit</button>
    </form>

    <?php if ($submitted_prescription): ?>
        <h2>Prescription Submitted Successfully!</h2>
        <p><strong>Patient Name:</strong> <?php echo htmlspecialchars($submitted_prescription['patient_name']); ?></p>
        <p><strong>Doctor Name:</strong> <?php echo htmlspecialchars($submitted_prescription['doctor_name']); ?></p>
        <p><strong>Medicine Name:</strong> <?php echo htmlspecialchars($submitted_prescription['medicine_name']); ?></p>
        <p><strong>Dosage:</strong> <?php echo htmlspecialchars($submitted_prescription['dosage']); ?></p>
        <p><strong>Instructions:</strong> <?php echo htmlspecialchars($submitted_prescription['instructions']); ?></p>
    <?php endif; ?>
</body>
</html>
