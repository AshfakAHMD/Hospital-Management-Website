document.addEventListener('DOMContentLoaded', function () {
    const appointmentDate = document.getElementById('date');
    let today = new Date();
    let day = today.getDate().toString().padStart(2, '0');
    let month = (today.getMonth() + 1).toString().padStart(2, '0');
    let year = today.getFullYear();
    let minDate = `${year}-${month}-${day}`;
    appointmentDate.setAttribute('min', minDate);

    const appointmentForm = document.querySelector('form');
    appointmentForm.addEventListener('submit', function (event) {
        const patientName = document.getElementById('name').value;
        const doctorSelect = document.getElementById('doctor').value;
        const appointmentTime = document.getElementById('time').value;

        if (patientName === '' || doctorSelect === '' || appointmentDate.value === '' || appointmentTime === '') {
            event.preventDefault();
            alert('Please fill in all fields.');
        } else {
            alert('Appointment booked successfully!');
        }
    });
});
