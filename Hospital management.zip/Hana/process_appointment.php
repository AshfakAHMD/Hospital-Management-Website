<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $doctor_id = $_POST['doctor_id'];
    $patient_name = $_POST['patient_name'];
    $appointment_date = $_POST['appointment_date'];

    // Insert the booking into the appointments table
    $sql = "INSERT INTO appointments (doctor_id, patient_name, appointment_date) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $doctor_id, $patient_name, $appointment_date);

    if ($stmt->execute()) {
        // Fetch the details of the recorded appointment
        $appointment_id = $stmt->insert_id;
        $stmt->close();

        $query = "SELECT a.id, a.patient_name, a.appointment_date, d.name AS doctor_name, d.available_time 
                  FROM appointments a
                  JOIN doctor_det d ON a.doctor_id = d.id
                  WHERE a.id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $appointment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $appointment = $result->fetch_assoc();

        // Display the booking details
        if ($appointment) {
            echo "<h1 class='display-4 text-center text-success'>Booking Successful!</h1>";
            echo "<div class='container mt-4'>";
            echo "<div class='card shadow-lg p-4'>";
            echo "<h3 class='card-title'>Appointment Details</h3>";
            echo "<ul class='list-group list-group-flush'>";
            echo "<li class='list-group-item'><strong>Appointment ID:</strong> " . htmlspecialchars($appointment['id']) . "</li>";
            echo "<li class='list-group-item'><strong>Patient Name:</strong> " . htmlspecialchars($appointment['patient_name']) . "</li>";
            echo "<li class='list-group-item'><strong>Doctor Name:</strong> " . htmlspecialchars($appointment['doctor_name']) . "</li>";
            echo "<li class='list-group-item'><strong>Available Time:</strong> " . htmlspecialchars($appointment['available_time']) . "</li>";
            echo "<li class='list-group-item'><strong>Appointment Date:</strong> " . htmlspecialchars($appointment['appointment_date']) . "</li>";
            echo "</ul>";
            echo "</div>";
            echo "</div>";
        } else {
            echo "<div class='container mt-4'>";
            echo "<div class='alert alert-danger' role='alert'>Error: Unable to retrieve booking details.</div>";
            echo "</div>";
        }
    } else {
        echo "<div class='container mt-4'>";
        echo "<div class='alert alert-danger' role='alert'>Error: " . $stmt->error . "</div>";
        echo "</div>";
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmation</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f4f7fc;
        }
        .container {
            max-width: 900px;
            margin-top: 50px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .card-title {
            color: #007bff;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="appointment.php" class="btn btn-primary mb-4">Go Back</a>
    </div>
</body>
</html>
