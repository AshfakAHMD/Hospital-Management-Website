<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "SELECT * FROM medicines WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $medicine = $result->fetch_assoc();
    } else {
        die("Medicine not found.");
    }
} else {
    die("Invalid request.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f4f7fc;
            font-family: 'Arial', sans-serif;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 30px;
        }
        table {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        th {
            background-color: #007bff;
            color: white;
            text-align: center;
        }
        td {
            text-align: center;
        }
        .form-group label {
            font-weight: bold;
        }
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
        .btn-container {
            display: flex;
            justify-content: space-between;
        }
        .cancel-btn {
            text-decoration: none;
        }
        .form-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Checkout</h2>
            <p class="text-center">Confirm your purchase for the following medicine:</p>
            <table class="table">
                <tr>
                    <th>Name:</th>
                    <td><?= htmlspecialchars($medicine['name']); ?></td>
                </tr>
                <tr>
                    <th>Type:</th>
                    <td><?= htmlspecialchars($medicine['type']); ?></td>
                </tr>
                <tr>
                    <th>Price (per unit):</th>
                    <td>$<?= htmlspecialchars($medicine['price']); ?></td>
                </tr>
            </table>

            <form action="process_payment.php" method="POST">
                <input type="hidden" name="medicine_id" value="<?= $medicine['id']; ?>">
                <input type="hidden" name="price" value="<?= $medicine['price']; ?>">
                
                <div class="form-group">
                    <label for="quantity">Enter Quantity:</label>
                    <input type="number" id="quantity" name="quantity" class="form-control" min="1" max="<?= $medicine['quantity']; ?>" required>
                </div>

                <div class="form-group">
                    <label for="payment_method">Choose Payment Method:</label>
                    <select id="payment_method" name="payment_method" class="form-control" required>
                        <option value="paypal">PayPal</option>
                        <option value="credit_card">Credit Card</option>
                    </select>
                </div>

                <div class="btn-container">
                    <button type="submit" class="btn btn-success">Pay Now</button>
                    <a href="pharmacy.php" class="btn btn-secondary cancel-btn">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
