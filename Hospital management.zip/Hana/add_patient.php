<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patient_name = isset($_POST['patient_name']) ? trim($_POST['patient_name']) : null;
    $patient_id_number = isset($_POST['patient_id_number']) ? trim($_POST['patient_id_number']) : null;
    $contact_number = isset($_POST['contact_number']) ? trim($_POST['contact_number']) : null;
    $reference_name = isset($_POST['reference_name']) ? trim($_POST['reference_name']) : null;
    $reference_contact = isset($_POST['reference_contact']) ? trim($_POST['reference_contact']) : null;
    $reason = isset($_POST['reason']) ? trim($_POST['reason']) : null;

    if ($patient_name && $patient_id_number) {
        try {
            $sql = "INSERT INTO patient_det (patient_name, patient_id_number, contact_number, reference_name, reference_contact, reason) 
                    VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssss", $patient_name, $patient_id_number, $contact_number, $reference_name, $reference_contact, $reason);

            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>Patient added successfully!</div>";
                echo '<a href="view_patients.php" class="btn btn-success">View Patients</a>';
            } else {
                echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
            }
            $stmt->close();
        } catch (mysqli_sql_exception $e) {
            echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
        }
    } else {
        echo "<div class='alert alert-warning'>Patient Name and ID Number are required!</div>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Patient</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Custom Styling -->
    <style>
        body {
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            font-family: 'Arial', sans-serif;
            color: white;
        }

        .navbar {
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }

        .navbar-brand img {
            height: 40px;
            margin-right: 10px;
        }

        .nav-link {
            color: #333;
            font-weight: bold;
            transition: all 0.3s;
        }

        .nav-link:hover {
            color: #007bff !important;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            color: #495057;
        }

        h2 {
            text-align: center;
            color: #495057;
            margin-bottom: 20px;
        }

        .form-control, .btn {
            margin-bottom: 15px;
        }

        .btn-primary {
            width: 100%;
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        .alert {
            margin-top: 15px;
            text-align: center;
        }

        footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }

        footer a {
            color: #ffc107;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="index.php">
        <img src="images/logo1.png" alt="Hospital Logo">
        <span>Hospital</span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
            <li class="nav-item"><a class="nav-link" href="doctors.php">Doctors</a></li>
            <li class="nav-item"><a class="nav-link" href="appointment.php">Book Appointment</a></li>
            <li class="nav-item"><a class="nav-link" href="pharmacy.php">Pharmacy</a></li>
            <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <h2>Add Patient Details</h2>
    <form method="POST">
        <div class="form-group">
            <label for="patient_name">Patient Name</label>
            <input type="text" class="form-control" id="patient_name" name="patient_name" required>
        </div>
        <div class="form-group">
            <label for="patient_id_number">Patient ID Number</label>
            <input type="text" class="form-control" id="patient_id_number" name="patient_id_number" required>
        </div>
        <div class="form-group">
            <label for="contact_number">Contact Number</label>
            <input type="text" class="form-control" id="contact_number" name="contact_number">
        </div>
        <div class="form-group">
            <label for="reference_name">Reference Name</label>
            <input type="text" class="form-control" id="reference_name" name="reference_name">
        </div>
        <div class="form-group">
            <label for="reference_contact">Reference Contact Number</label>
            <input type="text" class="form-control" id="reference_contact" name="reference_contact">
        </div>
        <div class="form-group">
            <label for="reason">Reason for Admitting</label>
            <textarea class="form-control" id="reason" name="reason"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Add Patient</button>
    </form>
</div>

<!-- Footer -->
<footer>
    <p>&copy; 2024 Hospital Management System. All Rights Reserved.</p>
    <p><a href="privacy-policy.php">Privacy Policy</a> | <a href="terms.php">Terms of Service</a></p>
</footer>

<!-- Bootstrap JS and Popper.js -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
