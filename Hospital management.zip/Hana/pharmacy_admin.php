<?php
include 'config.php';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_medicine'])) {
        $name = $_POST['name'];
        $type = $_POST['type'];
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];
        $expiry_date = $_POST['expiry_date'];

        $sql = "INSERT INTO medicines (name, type, price, quantity, expiry_date) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        $stmt->bind_param("ssdii", $name, $type, $price, $quantity, $expiry_date);

        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Medicine added successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error adding medicine: " . $stmt->error . "</div>";
        }

        $stmt->close();
    } elseif (isset($_POST['delete_medicine'])) {
        $medicine_id = $_POST['medicine_id'];

        $sql = "DELETE FROM medicines WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $medicine_id);

        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Medicine deleted successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error deleting medicine: " . $stmt->error . "</div>";
        }

        $stmt->close();
    }
}

// Fetch medicines
$result = $conn->query("SELECT * FROM medicines");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacy Admin</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        body {
            background-color: #f0f2f5;
            font-family: 'Arial', sans-serif;
        }
        .container {
            max-width: 1000px;
            margin-top: 30px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }
        .form-control, .btn {
            margin-bottom: 10px;
        }
        .btn {
            font-size: 1.1rem;
        }
        .card {
            border-radius: 10px;
        }
        .card-header {
            background-color: #28a745;
            color: white;
            text-align: center;
            font-size: 1.5rem;
        }
        table {
            margin-top: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        table th, table td {
            text-align: center;
            vertical-align: middle;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .btn-danger {
            background-color: #ff4d4d;
            border-color: #ff4d4d;
        }
        .btn-danger:hover {
            background-color: #e60000;
            border-color: #e60000;
        }
        footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Hospital Management</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
            <li class="nav-item"><a class="nav-link" href="pharmacy.php">Pharmacy</a></li>
            <li class="nav-item"><a class="nav-link" href="appointments.php">Appointments</a></li>
            <li class="nav-item active"><a class="nav-link" href="pharmacy_admin.php">Pharmacy Admin</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <h1>Pharmacy Inventory Management</h1>

    <!-- Add New Medicine Form -->
    <div class="card">
        <div class="card-header">
            Add New Medicine
        </div>
        <div class="card-body">
            <form method="POST">
                <div class="form-group">
                    <input type="text" name="name" class="form-control" placeholder="Medicine Name" required>
                </div>
                <div class="form-group">
                    <input type="text" name="type" class="form-control" placeholder="Type (e.g., Tablet, Syrup)" required>
                </div>
                <div class="form-group">
                    <input type="number" step="0.01" name="price" class="form-control" placeholder="Price" required>
                </div>
                <div class="form-group">
                    <input type="number" name="quantity" class="form-control" placeholder="Quantity" required>
                </div>
                <div class="form-group">
                    <input type="date" name="expiry_date" class="form-control" required>
                </div>
                <button type="submit" name="add_medicine" class="btn btn-success btn-block">Add Medicine</button>
            </form>
        </div>
    </div>

    <!-- Medicines Table -->
    <h2 class="mt-5">Current Medicines</h2>
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Expiry Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['type']) ?></td>
                        <td>$<?= htmlspecialchars($row['price']) ?></td>
                        <td><?= htmlspecialchars($row['quantity']) ?></td>
                        <td><?= htmlspecialchars($row['expiry_date']) ?></td>
                        <td>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="medicine_id" value="<?= $row['id'] ?>">
                                <button type="submit" name="delete_medicine" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Footer -->
<footer>
    <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
