<?php
include 'config.php';

// Fetch all doctors from the doctor_det table
$query = "SELECT id, name, available_time FROM doctor_det";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f4f7fc;
            font-family: 'Arial', sans-serif;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
            padding: 20px;
        }
        h1 {
            color: #007bff;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-group label {
            font-weight: bold;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
        footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Hospital Hub</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
            <li class="nav-item"><a class="nav-link" href="pharmacy.php">Pharmacy</a></li>
            <li class="nav-item active"><a class="nav-link" href="appointment.php">Appointments</a></li>
            <li class="nav-item"><a class="nav-link" href="add_patient.php">Add Patient</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <div class="card">
        <h1>Book an Appointment</h1>
        <form action="process_appointment.php" method="POST">
            <div class="form-group">
                <label for="doctor">Select Doctor</label>
                <select name="doctor_id" id="doctor" class="form-control" required>
                    <option value="" disabled selected>Choose a Doctor</option>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['id'] . "'>" . $row['name'] . " - " . $row['available_time'] . "</option>";
                        }
                    } else {
                        echo "<option value='' disabled>No doctors available</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="available_time">Available Time:</label>
                <p id="available_time" class="text-info">Select a doctor to see availability.</p>
            </div>
            <div class="form-group">
                <label for="patient_name">Your Name</label>
                <input type="text" name="patient_name" id="patient_name" class="form-control" placeholder="Enter your name" required>
            </div>
            <div class="form-group">
                <label for="appointment_date">Appointment Date</label>
                <input type="date" name="appointment_date" id="appointment_date" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Book Appointment</button>
        </form>
    </div>
</div>

<!-- Footer -->
<footer>
    <p>&copy; 2024 Hospital Management System. All rights reserved.</p>
</footer>

<script>
    const doctorSelect = document.getElementById('doctor');
    const availableTime = document.getElementById('available_time');

    doctorSelect.addEventListener('change', () => {
        const selectedOption = doctorSelect.options[doctorSelect.selectedIndex].text;
        const timeMatch = selectedOption.match(/- (.+)$/);
        availableTime.textContent = timeMatch ? timeMatch[1] : "Not Available";
    });
</script>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
