<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medicine_id = intval($_POST['medicine_id']);
    $quantity = intval($_POST['quantity']);
    $payment_method = $_POST['payment_method'];
    $price = floatval($_POST['price']);
    $total_amount = $quantity * $price;

    // Fetch medicine details
    $sql = "SELECT * FROM medicines WHERE id = $medicine_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $medicine = $result->fetch_assoc();

        // Check stock availability
        if ($quantity > $medicine['quantity']) {
            die("Insufficient stock. Please choose a smaller quantity.");
        }

        // Simulate payment processing (replace with actual payment gateway integration)
        $is_payment_successful = true; // Replace this with actual payment gateway logic

        if ($is_payment_successful) {
            // Deduct quantity from inventory
            $new_quantity = $medicine['quantity'] - $quantity;
            $update_sql = "UPDATE medicines SET quantity = $new_quantity WHERE id = $medicine_id";
            $conn->query($update_sql);

            // Save order details to the database
            $insert_order_sql = "INSERT INTO orders (medicine_id, quantity, total_amount, payment_method) 
                                 VALUES ($medicine_id, $quantity, $total_amount, '$payment_method')";
            $conn->query($insert_order_sql);

            // Success Message
            echo "<div class='container mt-5'>
                    <div class='row justify-content-center'>
                        <div class='col-lg-8'>
                            <div class='card shadow-lg border-0'>
                                <div class='card-body'>
                                    <h2 class='text-success text-center mb-4'><i class='fas fa-check-circle'></i> Payment Successful!</h2>
                                    <p class='text-center mb-4'>Your order has been successfully processed. Here is the summary of your order:</p>
                                    <div class='order-summary'>
                                        <ul class='list-group'>
                                            <li class='list-group-item'><strong>Medicine:</strong> " . htmlspecialchars($medicine['name']) . "</li>
                                            <li class='list-group-item'><strong>Quantity:</strong> $quantity</li>
                                            <li class='list-group-item'><strong>Total Amount:</strong> $$total_amount</li>
                                            <li class='list-group-item'><strong>Payment Method:</strong> " . htmlspecialchars($payment_method) . "</li>
                                        </ul>
                                    </div>
                                    <div class='text-center mt-4'>
                                        <a href='pharmacy.php' class='btn btn-lg btn-primary'>Back to Pharmacy</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>";
        } else {
            // Failure Message
            echo "<div class='container mt-5'>
                    <div class='row justify-content-center'>
                        <div class='col-lg-8'>
                            <div class='card shadow-lg border-0'>
                                <div class='card-body'>
                                    <h2 class='text-danger text-center mb-4'><i class='fas fa-times-circle'></i> Payment Failed!</h2>
                                    <p class='text-center mb-4'>There was an issue processing your payment. Please try again.</p>
                                    <div class='text-center'>
                                        <a href='checkout.php?id=$medicine_id' class='btn btn-lg btn-danger'>Go Back</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>";
        }
    } else {
        die("Medicine not found.");
    }
} else {
    header('Location: pharmacy.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Process</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- Animate CSS (for animation effects) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

    <!-- Custom Styling -->
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 10px;
        }
        .order-summary .list-group-item {
            font-size: 1.2rem;
            padding: 15px;
        }
        .btn {
            font-size: 1.1rem;
            padding: 10px 20px;
        }
        .container {
            max-width: 800px;
        }
        h2 {
            font-size: 2rem;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <!-- Content dynamically populated by PHP -->

    <!-- Optional: Scripts for Bootstrap and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
</body>
</html>
