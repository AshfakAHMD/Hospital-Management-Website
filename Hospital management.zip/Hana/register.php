<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    $sql = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $password, $role);

    if ($stmt->execute()) {
        header("Location: login.php?register=success");
        exit();
    } else {
        $error = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* General Styles */
        body {
            background: linear-gradient(to right, #007bff, #0056b3);
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 450px;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 100px;
        }

        /* Logo Section */
        .logo-container {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo-container img {
            width: 150px;
            height: auto;
        }

        h1 {
            color: #333;
            font-size: 2rem;
            margin-bottom: 20px;
            text-align: center;
        }

        /* Form Styles */
        .form-group label {
            font-size: 1.1em;
            color: #333;
        }

        .form-control {
            border-radius: 25px;
            box-shadow: none;
            border: 1px solid #ddd;
            padding: 12px 20px;
            font-size: 1em;
        }

        .form-control:focus {
            border-color: #007bff;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
            padding: 12px 20px;
            font-size: 1.1em;
            border-radius: 25px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }

        /* Error Message Styling */
        .alert {
            font-size: 1.1em;
            text-align: center;
            margin-bottom: 20px;
        }

        /* Text Link Styling */
        p {
            text-align: center;
            color: #007bff;
        }

        p a {
            color: #007bff;
            text-decoration: none;
        }

        p a:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>

    <div class="container">
        <!-- Logo Section -->
        <div class="logo-container">
            <img src="images/logo1.png" alt="Hospital Logo">
        </div>
        
        <h1>Register</h1>
        
        <!-- Success or Error Message -->
        <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        
        <!-- Registration Form -->
        <form method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select name="role" id="role" class="form-control" required>
                    <option value="admin">Admin</option>
                    <option value="doctor">Doctor</option>
                    <option value="patient">Patient</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Register</button>
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </form>
    </div>

</body>
</html>
