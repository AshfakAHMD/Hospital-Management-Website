<?php
// Start the session
session_start();
if (!isset($_SESSION['role'])) {
    $_SESSION['role'] = 'guest'; // Set default role for guests
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Management System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        .hero {
            background: linear-gradient(to right, #007bff, #6610f2);
            color: white;
            text-align: center;
            padding: 100px 0;
        }
        .hero h1 {
            font-size: 3rem;
            margin-bottom: 20px;
        }
        .hero p {
            font-size: 1.2rem;
        }
        .card img {
            max-height: 200px;
            object-fit: cover;
        }
        footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 20px 0;
        }
        footer a {
            color: #ffc107;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <!-- Logo added here -->
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="images/logo1.png" alt="Hospital Logo" style="height: 40px; margin-right: 10px;">
                Hospital Hub
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="doctors.php">Doctors</a></li>
                    <li class="nav-item"><a class="nav-link" href="appointment.php">Book Appointment</a></li>
                    <li class="nav-item"><a class="nav-link" href="pharmacy.php">Pharmacy</a></li>
                    <?php if ($_SESSION['role'] == 'admin'): ?>
                        <li class="nav-item"><a class="nav-link" href="pharmacy_admin.php">Admin Pharmacy</a></li>
                        <li class="nav-item"><a class="nav-link" href="add_patient.php">Add Patient</a></li>
                        <li class="nav-item"><a class="nav-link" href="view_patients.php">Patient Details</a></li>
                    <?php elseif ($_SESSION['role'] == 'doctor'): ?>
                        <li class="nav-item"><a class="nav-link" href="prescription.php">Submit Prescription</a></li>
                    <?php endif; ?>
                    <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero">
        <h1>Welcome to Hospital Hub</h1>
        <p>Your trusted healthcare partner</p>
        <a href="appointment.php" class="btn btn-light btn-lg mt-3">Book an Appointment</a>
    </div>

    <!-- Content Section -->
    <div class="container my-5">
        <h2 class="text-center mb-4">Explore Our Services</h2>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card">
                    <img src="images\doctor10.jpg" class="card-img-top" alt="Doctors">
                    <div class="card-body">
                        <h5 class="card-title">Our Doctors</h5>
                        <p class="card-text">Meet our experienced and dedicated medical team.</p>
                        <a href="doctors.php" class="btn btn-primary">View Doctors</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="images\pharmecy1.jpg" class="card-img-top" alt="Pharmacy">
                    <div class="card-body">
                        <h5 class="card-title">Pharmacy</h5>
                        <p class="card-text">Order your medications easily from our pharmacy.</p>
                        <a href="pharmacy.php" class="btn btn-primary">Visit Pharmacy</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="images\apointment1.jpg" class="card-img-top" alt="Appointments">
                    <div class="card-body">
                        <h5 class="card-title">Appointments</h5>
                        <p class="card-text">Schedule your appointments with our doctors.</p>
                        <a href="appointment.php" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2024 Hospital Hub. All rights reserved.</p>
            <p>Follow us on 
                <a href="#">Facebook</a>, 
                <a href="#">Twitter</a>, and 
                <a href="#">Instagram</a>.
            </p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
