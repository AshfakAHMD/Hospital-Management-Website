<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#">
        <img src="images/logo1.png" alt="Hospital Logo" style="height: 40px; margin-right: 10px;">
        <span>Hospital</span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
            <li class="nav-item"><a class="nav-link" href="doctors.php">Doctors</a></li>
            <li class="nav-item"><a class="nav-link" href="appointment.php">Book Appointment</a></li>
            <li class="nav-item"><a class="nav-link" href="pharmacy.php">Pharmacy</a></li>
            <?php if ($_SESSION['role'] == 'admin'): ?>
                <li class="nav-item"><a class="nav-link" href="pharmacy_admin.php">Admin Pharmacy</a></li>
                <li class="nav-item"><a class="nav-link" href="add_patient.php">Add Patient</a></li>
                <li class="nav-item"><a class="nav-link" href="view_patients.php">Patient Details</a></li>
            <?php elseif ($_SESSION['role'] == 'doctor'): ?>
                <li class="nav-item"><a class="nav-link" href="prescription.php">Submit Prescription</a></li>
            <?php endif; ?>
            <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>
