<?php include 'config.php'; ?>
<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctors</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* General Styling */
        body {
            background-image: url('images/backnew2.jpg');
            background-size: cover;
            background-attachment: fixed;
            color: #ffffff;
            font-family: 'Arial', sans-serif;
        }

        h1, h2 {
            text-align: center;
            color: #ffffff;
            margin-bottom: 30px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        /* Card Grid */
        .card {
            margin: 15px 0;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            background-color: rgba(255, 255, 255, 0.9);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card img {
            object-fit: cover;
            object-position: center;
            width: 100%;
            height: 200px;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .card img:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }

        .card-title {
            font-size: 1.3em;
            font-weight: bold;
            color: #007bff;
            text-align: center;
        }

        .card-text {
            font-size: 1em;
            color: #333;
            text-align: center;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        /* Row Styling */
        .row {
            margin-bottom: 30px;
        }

        /* Header and Footer */
        header {
            background: linear-gradient(to right, #007bff, #0056b3);
            color: #fff;
            text-align: center;
            padding: 20px 0;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
        }

        header h1 {
            font-size: 2.5rem;
            margin: 0;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
        }

        footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: auto;
        }

        footer a {
            color: #ffc107;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        .navbar {
            background: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .navbar-brand img {
            height: 40px;
            margin-right: 10px;
        }

        .nav-link {
            color: #555;
            font-weight: bold;
            transition: all 0.3s;
        }

        .nav-link:hover {
            color: #007bff !important;
            transform: scale(1.1);
        }

        /* Ensure content fills viewport before footer */
        .container {
            min-height: 80vh;
        }
    </style>
    <script>
        // Smooth scrolling to the doctors section
        function scrollToDoctors() {
            const doctorsSection = document.getElementById('doctors-section');
            if (doctorsSection) {
                doctorsSection.scrollIntoView({ behavior: 'smooth' });
            }
        }
    </script>
</head>
<body>
    <!-- Header -->
    

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="index.php">
            <img src="images/logo1.png" alt="Hospital Logo">
            <span>Hospital Hub</span>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link active" href="doctors.php">Doctors</a></li>
                <li class="nav-item"><a class="nav-link" href="appointment.php">Book Appointment</a></li>
                <li class="nav-item"><a class="nav-link" href="pharmacy.php">Pharmacy</a></li>
                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <li class="nav-item"><a class="nav-link" href="pharmacy_admin.php">Admin Pharmacy</a></li>
                    <li class="nav-item"><a class="nav-link" href="add_patient.php">Add Patient</a></li>
                    <li class="nav-item"><a class="nav-link" href="view_patients.php">Patient Details</a></li>
                <?php endif; ?>
                <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Existing Content -->
    <div class="container mt-5">
        <h1>Our Specialist Categories</h1>
        <div class="row">
            <?php
            // Manually define category images
            $categories = [
                1 => ['name' => 'Cardiology', 'image' => 'images/cardiology.jpg'],
                2 => ['name' => 'Neurology', 'image' => 'images/neurology.jpg'],
                3 => ['name' => 'Orthopedics', 'image' => 'images/orthopedics.jpg'],
                4 => ['name' => 'Pediatrics', 'image' => 'images/pediatrics.jpg'],
                5 => ['name' => 'Dermatology', 'image' => 'images/dermatology.jpg'],
                6 => ['name' => 'Physiotherapist', 'image' => 'images/Physiotherapist.jpg'],
            ];

            // Fetch categories from the database
            $sql = "SELECT * FROM categories";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $category_id = $row['id'];
                    $category_name = htmlspecialchars($row['name']);
                    $image_path = isset($categories[$category_id]) ? $categories[$category_id]['image'] : 'images/default_category.jpg';

                    echo '<div class="col-md-4">';
                    echo '<div class="card">';
                    echo '<img src="' . htmlspecialchars($image_path) . '" class="card-img-top" alt="' . htmlspecialchars($category_name) . '">';
                    echo '<div class="card-body">';
                    echo '<h5 class="card-title">' . htmlspecialchars($category_name) . '</h5>';
                    echo '<p class="card-text">Explore the best doctors in ' . htmlspecialchars($category_name) . '.</p>';
                    echo '<a href="doctors.php?category_id=' . $category_id . '#doctors-section" class="btn btn-primary btn-block" onclick="scrollToDoctors()">View Doctors</a>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p class="text-center">No categories found.</p>';
            }
            ?>
        </div>

        <?php
        if (isset($_GET['category_id'])) {
            $category_id = $_GET['category_id'];
            $sql = "SELECT doctor_det.id, doctor_det.name, doctor_det.available_time, doctor_det.image_path, categories.name AS category_name
                    FROM doctor_det
                    INNER JOIN categories ON doctor_det.category_id = categories.id
                    WHERE categories.id = $category_id";
            $result = $conn->query($sql);

            echo '<h2 class="mt-5" id="doctors-section">Available Doctors</h2>';
            echo '<div class="row">';
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $doctor_name = htmlspecialchars($row['name']);
                    $available_time = htmlspecialchars($row['available_time']);
                    $image_path = htmlspecialchars($row['image_path']);
                    echo '<div class="col-md-4">';
                    echo '<div class="card">';
                    echo '<img src="' . $image_path . '" class="card-img-top" alt="' . htmlspecialchars($doctor_name) . '">';
                    echo '<div class="card-body">';
                    echo '<h5 class="card-title">' . htmlspecialchars($doctor_name) . '</h5>';
                    echo '<p class="card-text">Available Time: ' . htmlspecialchars($available_time) . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p class="text-center col-md-12">No doctors available in this category.</p>';
            }
            echo '</div>';
        }
        ?>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; <?= date('Y'); ?> Your Hospital Management System. All rights reserved. <br>
        <a href="privacy-policy.php">Privacy Policy</a> | <a href="terms.php">Terms of Service</a></p>
    </footer>
</body>
</html>
