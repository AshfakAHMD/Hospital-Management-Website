<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Hospital Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* General Styling */
        body {
            background-image: url('images/backnew2.jpg');
            background-size: cover;
            background-attachment: fixed;
            color: #fff;
            font-family: Arial, sans-serif;
        }

        h1, h2 {
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
        }

        .container {
            background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent black */
            border-radius: 8px;
            padding: 20px;
            margin-top: 30px;
            color: #fff; /* Ensure text is white for contrast */
        }

        section {
            margin-bottom: 30px;
        }

        p, ul {
            font-size: 1.1em;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Navbar Styling */
        .navbar {
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }

        .navbar-brand img {
            height: 40px;
            margin-right: 10px;
        }

        .nav-link {
            color: #333;
            font-weight: bold;
            transition: all 0.3s;
        }

        .nav-link:hover {
            color: #007bff !important;
        }

        /* Card and Team Styling */
        .card {
            background-color: rgba(255, 255, 255, 0.8);
            border: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        .card-title {
            color: #333;
        }

        .card-img-top,
        .team-img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
        }

        .team-img {
            height: 150px;
            width: 150px;
            border-radius: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
        }

        .team-section .col-md-3 {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }

        .team-section .team-name {
            font-size: 1.2em;
            font-weight: bold;
            margin-top: 10px;
            color: #fff;
        }

        .team-section .team-role {
            color: lightgray;
        }

        /* Footer Styling */
        footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 20px 0;
        }

        footer a {
            color: #ffc107;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="index.php">
            <img src="images/logo1.png" alt="Hospital Logo">
            <span>Hospital Hub</span>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="doctors.php">Doctors</a></li>
                <li class="nav-item"><a class="nav-link" href="appointment.php">Book Appointment</a></li>
                <li class="nav-item"><a class="nav-link" href="pharmacy.php">Pharmacy</a></li>
                <li class="nav-item"><a class="nav-link text-danger" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Header -->
    <header class="bg-primary text-white text-center py-5">
        <h1>About Us</h1>
        <p>Learn more about our hospital, mission, and team</p>
    </header>

    <!-- Main Content -->
    <main class="container my-5">
        <section>
            <h2 class="text-primary">Our Mission</h2>
            <p>
                Our mission is to provide compassionate, accessible, high-quality, and cost-effective healthcare to the community. 
                We aim to enhance the health and well-being of every individual through our excellent medical services.
            </p>
        </section>

        <section>
            <h2 class="text-primary">Our Vision</h2>
            <p>
                To be the leading healthcare provider in the region, setting the benchmark for clinical excellence, 
                innovative practices, and community trust.
            </p>
        </section>

        <section>
            <h2 class="text-primary">Our Services</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <img src="images/back5.jpg" class="card-img-top" alt="Healthcare">
                        <div class="card-body">
                            <h5 class="card-title">Healthcare</h5>
                            <p class="card-text">Comprehensive care for patients of all ages.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <img src="images/back6.jpg" class="card-img-top" alt="Pharmacy">
                        <div class="card-body">
                            <h5 class="card-title">Pharmacy</h5>
                            <p class="card-text">We offer a fully equipped pharmacy to meet all your healthcare needs.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <img src="images/back8.jpg" class="card-img-top" alt="Surgery">
                        <div class="card-body">
                            <h5 class="card-title">Surgery</h5>
                            <p class="card-text">State-of-the-art surgical facilities and expertise.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="team-section">
            <h2 class="text-primary">Meet Our Team</h2>
            <div class="row">
                <div class="col-md-3">
                    <img src="images/doctor1.jpg" class="team-img mb-3" alt="Dr. John Doe">
                    <div class="team-name">Dr. John Doe</div>
                    <div class="team-role">Chief Surgeon</div>
                </div>
                <div class="col-md-3">
                    <img src="images/doctor2.jpg" class="team-img mb-3" alt="Dr. Jane Smith">
                    <div class="team-name">Dr. Jane Smith</div>
                    <div class="team-role">Pediatric Specialist</div>
                </div>
                <div class="col-md-3">
                    <img src="images/doctor7.jpg" class="team-img mb-3" alt="Dr. Alex Brown">
                    <div class="team-name">Dr. Fathima Hana</div>
                    <div class="team-role">Cardiologist</div>
                </div>
                <div class="col-md-3">
                    <img src="images/doctor9.jpg" class="team-img mb-3" alt="Dr. Emily White">
                    <div class="team-name">Dr. Emily White</div>
                    <div class="team-role">General Practitioner</div>
                </div>
            </div>
        </section>

        <section>
            <h2 class="text-primary">Contact Us</h2>
            <p>If you have any questions, feel free to reach out to us:</p>
            <ul>
                <li>Email: <a href="mailto:info@hospital.com">info@hospital.com</a></li>
                <li>Phone: +94 717785852</li>
                <li>Address: 123 Healthcare Lane, MediCity</li>
            </ul>
        </section>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Hospital Management System. All Rights Reserved.</p>
        <p><a href="privacy-policy.php">Privacy Policy</a> | <a href="terms.php">Terms of Service</a></p>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
